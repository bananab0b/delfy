# Survey Demo

This is the demo page for [survey](https://github.com/runtimerevolution/survey), a gem that brings quizzes, surveys and contests into your Rails application.

Can be tested here: [Survey Demo](http://survey-demo.herokuapp.com/)